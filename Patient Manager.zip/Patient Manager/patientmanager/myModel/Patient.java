package com.example.feranmi.patientmanager.myModel;

import android.net.Uri;

/**
 * Created by Feranmi on 8/25/2017.
 */
public class Patient {

    private int id;
    private String name, details;
    private String phone;
    private Uri photoURI;

    //This is empty constructor
    public Patient(){}

    public Patient(int _id, String nm, String det, String ph, Uri _uri ){

        id = _id;
        name = nm;
        details = det;
        phone = ph;
        photoURI = _uri;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public String getDetails() {
        return details;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhotoURI(Uri photoURI) {
        this.photoURI = photoURI;
    }

    public Uri getPhotoURI() {
        return photoURI;
    }
}

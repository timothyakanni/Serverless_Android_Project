package com.example.feranmi.patientmanager;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.media.Image;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;

import com.example.feranmi.patientmanager.myDB.DataBaseHelper;
import com.example.feranmi.patientmanager.myModel.Patient;
import com.example.feranmi.patientmanager.patientAdapter.PatientListAdapter;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    DataBaseHelper myDB;
    PatientListAdapter1 adapter;

    List<Patient> patientList = new ArrayList<Patient>();

    //Here we declare the values for add patient screen
    Button btnAddPatient;
    EditText editTextName, editTextDetails, editTextPhone;
    ImageView inputImage;

    Drawable noPatientImage;
    Uri defaultImage = Uri.parse("android.resource://PatientManager/app/src/main/res/drawable/tunnus.png");

    Boolean newEntry = true;

    //Here we declare the values for all patient screen
    ListView patientListView;

    ImageView listViewImage;
    TextView listViewName, listViewDetails, listViewPhone;

    TabHost tabHost;
    int patientIndex;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Here we initialize the database
        myDB = new DataBaseHelper(getApplicationContext());

        //Here we initialize the input from add patient screen
        btnAddPatient = (Button)findViewById(R.id.add_patient_button);
        editTextName = (EditText)findViewById(R.id.name_edit_text);
        editTextDetails = (EditText)findViewById(R.id.details_edit_text);
        editTextPhone = (EditText)findViewById(R.id.phone_edit_text);
        inputImage = (ImageView)findViewById(R.id.patientPhoto);

        noPatientImage = inputImage.getDrawable();

        //Here we the list view that contain all patients
        patientListView = (ListView)findViewById(R.id.patient_list_view);

        //Here we initialize the tab host
        tabHost = (TabHost) findViewById(R.id.tabHost);
        tabHost.setup();

        //Here we set up the first tab and add it to tabhost
        TabHost.TabSpec tabSpec1 = tabHost.newTabSpec("ADD PATIENT INFO");
        tabSpec1.setContent(R.id.layout_add_patient);
        tabSpec1.setIndicator("ADD PATIENT INFO");
        tabHost.addTab(tabSpec1);


        //Here we set up the first tab and add it to tabhost
        tabSpec1 = tabHost.newTabSpec("VIEW ALL PATIENTS");
        tabSpec1.setContent(R.id.layout_view_all_patient);
        tabSpec1.setIndicator("VIEW ALL PATIENTS");
        tabHost.addTab(tabSpec1);


        patientImageHandler();
        addPatientData();

        getAllPatient();

    }

    //This will handle the patient image part
    public void patientImageHandler(){
        inputImage.setOnClickListener(
                new View.OnClickListener(){

                    @Override
                    public void onClick(View view) {

                        Intent intent = new Intent();
                        intent.setType("image/*");
                        intent.setAction(Intent.ACTION_GET_CONTENT);

                        startActivityForResult(Intent.createChooser(intent, "Select Patient Image"), 1);
                    }
                }
        );


    }

    //Here the intent returns photo selected from gallery and put it in default image
    public void onActivityResult(int requestCode, int resultCode, Intent data){

        if(resultCode == RESULT_OK){
            if(requestCode == 1){
                newEntry = false;
                defaultImage = data.getData();
                inputImage.setImageURI(data.getData());
            }
        }

    }

    public void addPatientData(){
        btnAddPatient.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {


                        if (editTextName.getText().toString().isEmpty() ||
                                editTextDetails.getText().toString().isEmpty() ||
                                editTextPhone.getText().toString().isEmpty()) {

                            Toast.makeText(MainActivity.this, "Check Mssing Input", Toast.LENGTH_SHORT).show();

                        }else{
                            Patient patientInsert = new Patient();
                            patientInsert.setName(editTextName.getText().toString());
                            patientInsert.setDetails(editTextDetails.getText().toString());
                            patientInsert.setPhone( editTextPhone.getText().toString());
                            patientInsert.setPhotoURI(defaultImage);

                            myDB.insertPatient(patientInsert);

                            //Here we attached the last input of patient data to the patient list view
                            //patientList.clear();
                            getAllPatient();
                        }
                    }
                }
        );


    }


    //Here we get all patients
    public void getAllPatient(){

        if(myDB.getPatientsCount() != 0){

            patientList.addAll(myDB.getAllPatients());
            adapter = new PatientListAdapter1();

            patientListView.setAdapter(adapter);

        }
    }


    private class PatientListAdapter1 extends ArrayAdapter<Patient>{

        public PatientListAdapter1() {
            super(getApplicationContext(), R.layout.list_view_item, patientList);
        }


        @Override
        public View getView(int position, View view, ViewGroup parent) {

            if(view == null)
                view = getLayoutInflater().inflate(R.layout.list_view_item, parent, false);

            ImageView listViewPhoto = (ImageView)view.findViewById(R.id.patientPhoto);
            TextView listViewName = (TextView)view.findViewById(R.id.textViewName);
            TextView listViewDetail = (TextView)view.findViewById(R.id.textViewDetails);
            TextView listViewPhone = (TextView)view.findViewById(R.id.textViewPhone);


            Patient currentPatient = patientList.get(position);

            //Here we set image view and text view base on list item position
            listViewPhoto.setImageURI(currentPatient.getPhotoURI());
            listViewName.setText(currentPatient.getName());
            listViewDetail.setText(currentPatient.getDetails());
            listViewPhone.setText(currentPatient.getPhone());

            return view;
        }
    }

}

package com.example.feranmi.patientmanager;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

/**
 * Created by Feranmi on 8/28/2017.
 */
public class ActivityAddPatient extends Activity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_patient);


    }
}

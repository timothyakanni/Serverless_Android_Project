package com.example.feranmi.patientmanager.patientAdapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.feranmi.patientmanager.R;
import com.example.feranmi.patientmanager.myModel.Patient;

import java.util.List;

/**
 * Created by Feranmi on 8/30/2017.
 */
public class PatientListAdapter extends BaseAdapter{

    private Context context;
    private List<Patient> patients;

    //this is the class constructor
    public PatientListAdapter(Context context, List<Patient> patients) {
        this.context = context;
        this.patients = patients;
    }

    @Override
    public int getCount() {
        return patients.size();
    }

    @Override
    public Object getItem(int position) {
        return patients.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {

        //Here we initialize the views and cast v to image view and text view
        View v = View.inflate(context, R.layout.list_view_item, null);

        ImageView listViewPhoto = (ImageView)v.findViewById(R.id.patientPhoto);
        TextView listViewName = (TextView)v.findViewById(R.id.textViewName);
        TextView listViewDetail = (TextView)v.findViewById(R.id.textViewDetails);
        TextView listViewPhone = (TextView)v.findViewById(R.id.textViewPhone);


        Patient currentPatient = patients.get(position);

        //Here we set image view and text view base on list item position
        listViewPhoto.setImageURI(currentPatient.getPhotoURI());
        listViewName.setText(currentPatient.getName());
        listViewDetail.setText(currentPatient.getDetails());
        listViewPhone.setText(currentPatient.getPhone());

        return v;
    }


}

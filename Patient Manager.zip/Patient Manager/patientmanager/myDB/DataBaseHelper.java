package com.example.feranmi.patientmanager.myDB;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;

import com.example.feranmi.patientmanager.myModel.Patient;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Feranmi on 8/25/2017.
 */
public class DataBaseHelper extends SQLiteOpenHelper {

    //Here we define our constants
    private static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "Patient.db";
    public static final String TABLE_NAME = "patient_table";

    //These are the database table columns
    private static final String COL_1 = "Id";
    private static final String COL_2 = "Name";
    private static final String COL_3 = "Details";
    private static final String COL_4 = "Phone";
    private static final String COL_5 = "ImageUri";

    public DataBaseHelper(Context context) {
        super(context, TABLE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("create table " + TABLE_NAME + "(Id INTEGER PRIMARY KEY AUTOINCREMENT, Name TEXT, Details TEXT, " +
                "Phone REAL, ImageUri TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS" + TABLE_NAME);
        onCreate(db);
    }

    //This method is used to insert patient data into database
    public void insertPatient(Patient patient){

        SQLiteDatabase db = getWritableDatabase();

        String insert = "INSERT or replace INTO " + TABLE_NAME + "("+COL_2+", "+COL_3+", "+COL_4+", "+COL_5+") " +
                "VALUES('" + patient.getName() + "', '" + patient.getDetails() + "', '" + patient.getPhone()+ "', '"+patient.getPhotoURI()+"' )";
        db.execSQL(insert);
        db.close();

    }//end of insertPatient method

    //This method is used to get A patient info from database
    public Patient getPatient(int id){

        //SQLiteDatabase db = getReadableDatabase();
        SQLiteDatabase db = getWritableDatabase();

        Cursor cursor = db.query(TABLE_NAME, new String[]{COL_1,COL_2,COL_3,COL_4,
                COL_5}, COL_1 + "= ?",new String[]{String.valueOf(id)},null,null,null,null);

        if(cursor != null){
            cursor.moveToFirst();
        }

        Patient patient = new Patient();
            patient.setId(Integer.parseInt(cursor.getString(0)));
            patient.setDetails(cursor.getString(1));
            patient.setDetails(cursor.getString(2));
            patient.setPhone(cursor.getString(3));
            patient.setPhotoURI(Uri.parse(cursor.getString(4)));

        db.close();
        cursor.close();

        return patient;
    }//end of getPatient method

    //This method is used to delete patient info from database
    public void deletePatient(Patient patient){

        SQLiteDatabase db = getWritableDatabase();

        db.delete(TABLE_NAME, COL_1 + "=?", new String[]{String.valueOf(patient.getId())});
        db.close();
    }//end of deletePatient method

    //This method is used to update patient contact
    public boolean updatePatient(Patient patient){

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_1, patient.getId());
        contentValues.put(COL_2, patient.getName());
        contentValues.put(COL_3, patient.getDetails());
        contentValues.put(COL_4, patient.getPhone());
        contentValues.put(COL_5, patient.getPhotoURI().toString());

        long result = db.update(TABLE_NAME, contentValues, COL_1 + "= ?", new String[]{String.valueOf(patient.getId())});

        if(result == -1)
            return false;
        else
            return true;
    }//end of updatePatient method

    //this method is used to get counts of all the patient data in database
    public int getPatientsCount(){

        //SQLiteDatabase db = getReadableDatabase();
        SQLiteDatabase db = getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME, null);
        int count = cursor.getCount();

        db.close();;
        cursor.close();
        return count;
    }//end of getPatientsCount method

    //This method is used to get list of all patients in the database
    public List<Patient> getAllPatients(){

        List<Patient> allPatients = new ArrayList<Patient>();

        SQLiteDatabase db = getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME, null);

        if(cursor.moveToFirst()){

            do{
                Patient patient = new Patient();
                patient.setId(Integer.parseInt(cursor.getString(0)));
                patient.setName(cursor.getString(1));
                patient.setDetails(cursor.getString(2));
                patient.setPhone(cursor.getString(3));
                patient.setPhotoURI(Uri.parse(cursor.getString(4)));

                allPatients.add(patient);
            }
            while(cursor.moveToNext());
        }//end of if

        return allPatients;
    }


    //This method is used to get A patient info from database
    public Patient getLastPatientInput(){

        //SQLiteDatabase db = getReadableDatabase();
        SQLiteDatabase db = getWritableDatabase();

        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME, null);

        Patient patient = new Patient();
        if(cursor != null) {
            if (cursor.moveToLast()) {

                patient.setId(Integer.parseInt(cursor.getString(0)));
                patient.setDetails(cursor.getString(1));
                patient.setDetails(cursor.getString(2));
                patient.setPhone(cursor.getString(3));
                patient.setPhotoURI(Uri.parse(cursor.getString(4)));

                db.close();
                cursor.close();
            }
        }

        return patient;

    }//end of get last Patient Input method

}//end of class DataBaseHelper

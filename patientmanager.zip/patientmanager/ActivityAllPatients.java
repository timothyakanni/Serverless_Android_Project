package com.example.feranmi.patientmanager;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by Feranmi on 8/28/2017.
 */
public class ActivityAllPatients extends Activity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.all_patients);
    }
}

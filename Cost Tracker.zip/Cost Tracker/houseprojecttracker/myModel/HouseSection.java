package com.example.feranmi.houseprojecttracker.myModel;

/**
 * Created by Feranmi on 8/14/2017.
 */
public class HouseSection {
    private String section, status;
    private Integer id;
    private Double price;


    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
    public void setSection(String section){
        this.section = section;
    }
    public String getSection(){
        return section;
    }
    public void setStatus(String status){
        this.status = status;
    }
    public String getStatus(){
        return status;
    }
    public void setPrice(Double price){
        this.price = price;
    }
    public Double getPrice(){
        return price;
    }

}

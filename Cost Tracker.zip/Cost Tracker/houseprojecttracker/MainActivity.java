package com.example.feranmi.houseprojecttracker;

import android.app.AlertDialog;
import android.database.Cursor;
import android.icu.text.NumberFormat;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.example.feranmi.houseprojecttracker.myDB.DataBaseHelper;
import com.example.feranmi.houseprojecttracker.myModel.HouseSection;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    DataBaseHelper myDb;
    EditText editSection, editStatus, editPrice;
    Button btnInsert, btnDelete, btnUpdate;

    TextView textView_feedback;
    TextView textView_project_cost;

    ArrayList<HashMap<String, String>> dataList = new ArrayList<HashMap<String, String>>();
    ListView list;
    ListAdapter adapter;

    String section_id;
    double project_total_cost;

    //Here we define our constants
    public static final String TAG_ID = "ID";
    public static final String TAG_SECTION = "SECTION";
    public static final String TAG_PRICE = "PRICE";
    public static final String TAG_STATUS = "STATUS";


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Here we initialize the database
        myDb = new DataBaseHelper(this);

        editSection = (EditText) findViewById(R.id.editText_section);
        editStatus = (EditText) findViewById(R.id.editText_status);
        editPrice = (EditText) findViewById(R.id.editText_price);

        btnInsert = (Button) findViewById(R.id.button_insert);
        btnDelete = (Button) findViewById(R.id.button_delete);
        btnUpdate = (Button) findViewById(R.id.button_update);

        textView_feedback = (TextView) findViewById(R.id.textView_feedback);
        textView_project_cost = (TextView) findViewById(R.id.textView_project_costs);


        //These methods are called with clicking buttons events
        addData();
        delete();
        update();

        //These methods are called when the app is created without clicking button
        viewAllData();
        viewTotalPrice();
    }

    //This is the method that adds data to database and it calls insertData method
    public void addData() {
        btnInsert.setOnClickListener(
                new View.OnClickListener() {

                        @Override
                        public void onClick (View view) {


                            if (editSection.getText().toString().isEmpty() ||
                                    editStatus.getText().toString().isEmpty() ||
                                    editPrice.getText().toString().isEmpty()) {

                                textView_feedback.setText("   Check the missing Input");

                            } else {

                                textView_feedback.setText(" ");
                                HouseSection hsInsert = new HouseSection();
                                hsInsert.setSection(editSection.getText().toString());
                                hsInsert.setStatus(editStatus.getText().toString());
                                hsInsert.setPrice(Double.parseDouble(editPrice.getText().toString()));

                                boolean result = myDb.insertData(hsInsert);
                                //textView_feedback.setText(editSection.getText().toString());

                                if (result == true) {
                                    editSection.setText("");
                                    editStatus.setText("");
                                    editPrice.setText("");
                                    Toast.makeText(MainActivity.this, "Data is Inserted", Toast.LENGTH_SHORT).show();

                                    //Here we call the method that put the last input data in the table
                                    viewLastData();

                                    //Here we reset the project cost text view and then called view total price
                                    textView_project_cost.setText("COSTS:");
                                    viewTotalPrice();

                                } else
                                    Toast.makeText(MainActivity.this, "Data is not Inserted", Toast.LENGTH_SHORT).show();

                            }//end of first if else

                        }//end of onClick method

                }//end of onClickListener
        );
    }// end of addData method


    //This is the method that delete data from database and it calls deleteData method
    public void delete(){
        btnDelete.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        if (editSection.getText().toString().isEmpty() ||
                                editStatus.getText().toString().isEmpty() ||
                                editPrice.getText().toString().isEmpty()) {

                            textView_feedback.setText("   Check the missing Input");
                        } else {

                            textView_feedback.setText(" ");
                            //textView_feedback.setText(section_id);
                            int deletedRow = myDb.deleteData(section_id);
                            if(deletedRow > 0) {
                                Toast.makeText(MainActivity.this, "Data is Deleted", Toast.LENGTH_SHORT).show();

                                editSection.setText("");
                                editStatus.setText("");
                                editPrice.setText("");

                                //Here we clear the data in the table
                                dataList.clear();
                                list=(ListView) findViewById(R.id.tableDataListView);
                                adapter = new SimpleAdapter(MainActivity.this, dataList,
                                        R.layout.activity_main_list_item,
                                        new String[] {TAG_SECTION, TAG_PRICE, TAG_STATUS},
                                        new int[] {R.id.dataSection, R.id.dataPrice,
                                                R.id.dataStatus});

                                list.setAdapter(adapter);

                                //Here we reload the table with data in database
                                viewAllData();

                                //Here we reset the project cost text view and then called view total price
                                textView_project_cost.setText("COSTS:");
                                viewTotalPrice();
                            }
                            else {

                                Toast.makeText(MainActivity.this, "Data is not Deleted", Toast.LENGTH_SHORT).show();
                                //showMessage("Error:", "Data not found");
                                return;

                            }// end of inner if else

                        }//end of first if

                    }// end of on click

                }// end of on click listener

        );
    }// end of delete method

    public void update(){
        btnUpdate.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {


                        if (editSection.getText().toString().isEmpty() ||
                                editStatus.getText().toString().isEmpty() ||
                                editPrice.getText().toString().isEmpty()) {

                            textView_feedback.setText("   Check the missing Input");
                        } else {

                            textView_feedback.setText(" ");
                            HouseSection hsUpdate = new HouseSection();
                            hsUpdate.setSection(editSection.getText().toString());
                            hsUpdate.setStatus(editStatus.getText().toString());
                            hsUpdate.setPrice(Double.parseDouble(editPrice.getText().toString()));
                            hsUpdate.setId(Integer.parseInt(section_id));

                            boolean result = myDb.updateData(hsUpdate);
                            //textView_feedback.setText(section_id);

                            if (result == true) {
                                editSection.setText("");
                                editStatus.setText("");
                                editPrice.setText("");
                                Toast.makeText(MainActivity.this, "Data is Updated", Toast.LENGTH_SHORT).show();

                                //Here we clear the data list and then reload the table with latest info
                                dataList.clear();
                                viewAllData();

                                //Here we reset the project cost text view and then called view total price
                                textView_project_cost.setText("COSTS:");
                                viewTotalPrice();

                            } else
                                Toast.makeText(MainActivity.this, "Data is not Updated", Toast.LENGTH_SHORT).show();

                        }// end of first if else
                    }//end of on click
                }// end of on click listener
        );
    }

    //This method is used to get total Price from database table
    public void viewTotalPrice(){

            Cursor res = myDb.getPriceData();

            project_total_cost = 0.0;
            if(res != null){
                while(res.moveToNext()){

                    project_total_cost = project_total_cost + res.getDouble(0);
                }
            }else {
                showMessage("Error:", "Data not found");
                return;
            }


        textView_project_cost.append(" " + project_total_cost);
    }


    //This method is used to get info about all inputted data
    public void viewAllData() {

            Cursor res = myDb.getAllData();

            HouseSection hs;
            if(res != null){
                while(res.moveToNext()){

                    Integer hs_id = res.getInt(0);
                    String hs_section = res.getString(1);
                    double hs_price = res.getDouble(2);
                    String hs_status = res.getString(3);

                    hs = new HouseSection();

                    hs.setId(hs_id);
                    hs.setSection(hs_section);
                    hs.setPrice(hs_price);
                    hs.setStatus(hs_status);


                    HashMap<String, String> map = new HashMap<String, String>();
                    map.put(TAG_ID, Integer.toString(hs.getId()));
                    map.put(TAG_SECTION, hs.getSection());
                    map.put(TAG_PRICE, Double.toString(hs.getPrice()));
                    map.put(TAG_STATUS, hs.getStatus());

                    dataList.add(map);
                    list=(ListView) findViewById(R.id.tableDataListView);

                    adapter = new SimpleAdapter(MainActivity.this, dataList,
                            R.layout.activity_main_list_item,
                            new String[] {TAG_SECTION, TAG_PRICE, TAG_STATUS},
                            new int[] {R.id.dataSection, R.id.dataPrice,
                                    R.id.dataStatus});


                    list.setAdapter(adapter);

                    //Setting click listener for each item in Course List View
                    list.setOnItemClickListener(new AdapterView.OnItemClickListener() {

                            @Override
                            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {

                                editSection.setText(dataList.get(+position).get(TAG_SECTION));
                                editPrice.setText(dataList.get(+position).get(TAG_PRICE));
                                editStatus.setText(dataList.get(+position).get(TAG_STATUS));
                                section_id = dataList.get(+position).get(TAG_ID);
                                //textView_feedback.setText("  " +section_id);
                            }
                        }

                    );



                }//end of while loop
            }
            else {

                showMessage("Error:", "Data not found");
                return;
            }

    }

    //This method is used to get information about last inputted data
    public void viewLastData() {

            Cursor res = myDb.getAllData();

            HouseSection hs;
            if(res != null){
                //This is the important area that get the last data
                if(res.moveToLast()){

                    Integer hs_id = res.getInt(0);
                    String hs_section = res.getString(1);
                    double hs_price = res.getDouble(2);
                    String hs_status = res.getString(3);

                    hs = new HouseSection();
                    hs.setId(hs_id);
                    hs.setSection(hs_section);
                    hs.setPrice(hs_price);
                    hs.setStatus(hs_status);


                    HashMap<String, String> map = new HashMap<String, String>();
                    map.put(TAG_ID, Integer.toString(hs.getId()));
                    map.put(TAG_SECTION, hs.getSection());
                    map.put(TAG_PRICE, Double.toString(hs.getPrice()));
                    map.put(TAG_STATUS, hs.getStatus());

                    dataList.add(map);
                    list=(ListView) findViewById(R.id.tableDataListView);

                    adapter = new SimpleAdapter(MainActivity.this, dataList,
                            R.layout.activity_main_list_item,
                            new String[] {TAG_SECTION, TAG_PRICE, TAG_STATUS},
                            new int[] {R.id.dataSection, R.id.dataPrice,
                                    R.id.dataStatus});


                    list.setAdapter(adapter);


                    //Setting click listener for each item in Course List View
                    list.setOnItemClickListener(new AdapterView.OnItemClickListener() {

                            @Override
                            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {

                                editSection.setText(dataList.get(+position).get(TAG_SECTION));
                                editPrice.setText(dataList.get(+position).get(TAG_PRICE));
                                editStatus.setText(dataList.get(+position).get(TAG_STATUS));
                                section_id = dataList.get(+position).get(TAG_ID);
                                //textView_feedback.setText("  "+section_id);
                            }
                        }
                    );



                }else{
                    showMessage("Error:", "Data not found");
                    return;
                }


            }
            else if(res.getCount() == 0){
                showMessage("Error:", "Data not found");
                return;
            }


    }

    //This is the method that display messages and it is taking message as parameter
    public void showMessage(String title, String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }


}

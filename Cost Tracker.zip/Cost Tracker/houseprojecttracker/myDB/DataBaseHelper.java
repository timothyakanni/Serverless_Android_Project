package com.example.feranmi.houseprojecttracker.myDB;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.feranmi.houseprojecttracker.myModel.HouseSection;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by Feranmi on 8/13/2017.
 */
public class DataBaseHelper extends SQLiteOpenHelper {

    //Here we define our constants
    public static final String DATABASE_NAME = "House.db";
    public static final String TABLE_NAME = "house_table";
    //These are the table columns
    public static final String COL_1 = "Id";
    public static final String COL_2 = "Section";
    public static final String COL_3 = "Price";
    public static final String COL_4 = "Status";

    //This is class constructor
    public DataBaseHelper(Context context)
    {
        super(context, DATABASE_NAME, null, 1);
    }

    //This is an inherited method
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + TABLE_NAME + "(Id INTEGER PRIMARY KEY AUTOINCREMENT, Section TEXT, Price REAL, Status TEXT)");
    }

    //This is an inherited method
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS" + TABLE_NAME);
        onCreate(db);
    }

    //This method is used to insert house data into database
    public boolean insertData(HouseSection houseSection){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_2, houseSection.getSection());
        contentValues.put(COL_3, houseSection.getPrice());
        contentValues.put(COL_4, houseSection.getStatus());
        long result = db.insert(TABLE_NAME,null, contentValues);
        if(result == -1)
            return false;
        else
            return true;

    }


    //This method is used to get all the house info in the database
    public Cursor getAllData(){

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor result = db.rawQuery("select * from " + TABLE_NAME, null);

        return result;
    }

    //This method is used to get Price info from Price column in the database
    public Cursor getPriceData(){

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor result = db.rawQuery("select Price from " + TABLE_NAME, null);

        return result;
    }

    //This method is used to deleted house info from database
    public Integer deleteData(String sectionId){

        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        return sqLiteDatabase.delete(TABLE_NAME, "Id = ?", new String[]{sectionId});

    }

    //This method is used to update house info in the database
    public boolean updateData(HouseSection houseSection){

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_1, houseSection.getId());
        contentValues.put(COL_2, houseSection.getSection());
        contentValues.put(COL_3, houseSection.getPrice());
        contentValues.put(COL_4, houseSection.getStatus());
        long result = db.update(TABLE_NAME, contentValues, "Id = ?", new String[]{houseSection.getId().toString()});

        if(result == -1)
            return false;
        else
            return true;
    }
}
